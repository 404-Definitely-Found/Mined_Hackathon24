import sqlite3
import pdfToText

class Database_common_operations:
    """
        This is base class for all other database classes, This class will have all classmethods only.
    """

    @classmethod
    def run_query(cls, query: str):
        """
        This method is used to run a query.
        :param query: Must be in valid SQL syntax.
        :return: None
        """

        conn = sqlite3.connect("database.db")
        cursor = conn.cursor()
        cursor.execute(query)
        conn.commit()
        cursor.close()
        conn.close()

    @classmethod
    def run_query_and_return_all_data(cls, query):
        """
               This method is used to run a query.
               :param query: Must be in valid SQL syntax.
               :return: None
               """

        conn = sqlite3.connect("database.db")
        cursor = conn.cursor()
        cursor.execute(query)
        data = cursor.fetchall()
        conn.commit()
        cursor.close()
        conn.close()
        return data
    

def input(name: str, email: str, res_path: str, file_name: str):
    print('here!')
    query = f"insert into Master values('{name}', '{email}', '{res_path}');"
    x = Database_common_operations.run_query(query)

    flag = pdfToText.extract_text_from_pdf(res_path,file_name)
    if flag:
        print("Yersss")
    return x 