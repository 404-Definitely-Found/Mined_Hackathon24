from flask import Flask, render_template, request, flash, session, redirect
from fileinput import filename 
from werkzeug.utils import secure_filename
import os.path
import database
import pdfToText
import time

app = Flask(__name__)
app.secret_key = 'abcdefghi#123'

@app.route('/')
def home():
    return render_template('index.html')

UPLOAD_FOLDER = "C:/Users/chinmay/Desktop/hackathon/resumes"
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg',''}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/file_upload', methods=['POST'])
def file_upload():
    if request.method == 'POST':   
        exts = ['.txt','.pdf','.png','.jpg','.jpeg']

        name = request.form['Name']
        email = request.form['Email']

        if 'file' not in request.files:
            flash('No file part')
            return redirect('/')
        file = request.files['file']
        if file.filename == '':
            flash('No selected file')
            return redirect('/')
        if file:
            x = file.filename[file.filename.index('.'):]
            filename = secure_filename(file.filename)
            x = x[::-1]
            x = file.filename[(len(file.filename)-x.index('.')-1):]
            if x not in exts:
                flash('Please upload document of specified formats: .txt,.pdf,.png,.jpg,.jpeg','error')
                return redirect('/')
            #if not x == '.pdf':
                #handle conversion
            res_path = "C:/Users/chinmay/Desktop/hackathon/resumes/"+file.filename
            
            
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename)) 
            time.sleep(3)
            
        
        database.input(name,email,res_path,file.filename)
        return x

if __name__ == "__main__":
    app.run(debug=True)