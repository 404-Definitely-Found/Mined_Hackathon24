import PyPDF2

def extract_text_from_pdf(pdf_path, name):
    try:
        print(pdf_path)
        output_txt_path = f"C:/Users/chinmay/Desktop/hackathon/output/{name}.txt"
        text_lines = []
        with open(pdf_path, 'rb') as pdf_file:
            pdf_reader = PyPDF2.PdfReader(pdf_file)
            
            for page_num in range(len(pdf_reader.pages)):
                page = pdf_reader.pages[page_num]
                text_lines.extend(page.extract_text().split('\n'))

        with open(output_txt_path, 'w', encoding='utf-8') as txt_file:
            txt_file.write('\n'.join(text_lines))

        return True
    except Exception as e:
        print(f"Error: {e}")
        return False
    
    #"C:\Users\chinmay\Desktop\hackathon\resumes\textF"

extract_text_from_pdf('C:/Users/chinmay/Desktop/hackathon/resumes/Segmentation.pdf', "trying1.txt")